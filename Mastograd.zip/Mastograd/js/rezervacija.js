function submitForm() {
    if($( "input[name='imeiprezime']").val() == '' || $("input[name='brojgostiju']").val() == ''|| $("input[name='datum']").val() == ''){
        alert('Niste uneli sve potrebne podatke.');

        if($( "input[name='imeiprezime']").val() == '') $( "input[name='imeiprezime']")[0].style.backgroundColor = '#FF6C64';
        if($( "input[name='brojgostiju']").val() == '') $( "input[name='brojgostiju']")[0].style.backgroundColor = '#FF6C64';
        if($( "input[name='datum']").val() == '') $( "input[name='datum']")[0].style.backgroundColor = '#FF6C64';

    }
    else if ($("select[name='select']").val() == null) {
        alert('Niste odredili koji paket želite.');
        $( "select[name='select']")[0].style.backgroundColor = '#FF6C64';
    }
    else {
        alert("Hvala na rezervaciji!");
        window.location.reload();
    }

}