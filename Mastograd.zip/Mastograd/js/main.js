function toggleMenu() {
    var menu = $("#menu")[0];
    if (menu.style.display == "none" || menu.style.display == '') {
        menu.style.display = "block";
    } else {
        menu.style.display = "none";
    }
}

function changeLocation(location){
        window.location.pathname = "EPOS/" + location;
}


$(document).ready(function () {
    var menu = $("#menu")[0];
    if(window.location.pathname != "/Maštograd/index.html"){
        menu.style.display = "block";

        if(window.location.pathname == "/Maštograd/onama.html"){
            $("#about-us")[0].firstElementChild.style.color = "white    "
        }
        else if(window.location.pathname == "/Maštograd/rezervacija.html"){
            $("#reservation")[0].nextElementChild.style.color = "white"
        }
        else {
            $("#gallery")[0].nextElementChild.style.color = "white"
        }
    }

    else {
        $("#home")[0].secondtElementChild.style.color = "white"
    }
});